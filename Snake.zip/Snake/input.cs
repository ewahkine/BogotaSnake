﻿using Raylib_cs;
using System.ComponentModel;

public class input
{
    public Coordinates Direction { get; private set; } = Coordinates.right;
    private Coordinates pendingDirection = Coordinates.right;

    public void UpdateDirection()
    {
        if ((Raylib.IsKeyDown(KeyboardKey.Up) || Raylib.IsKeyDown(KeyboardKey.Z) || Raylib.IsKeyDown(KeyboardKey.W))
            && Direction != Coordinates.down)
        {
            pendingDirection = Coordinates.up;
        }
        else if ((Raylib.IsKeyDown(KeyboardKey.Down) || Raylib.IsKeyDown(KeyboardKey.S))
            && Direction != Coordinates.up)
        {
            pendingDirection = Coordinates.down;
        }
        else if ((Raylib.IsKeyDown(KeyboardKey.Left) || Raylib.IsKeyDown(KeyboardKey.Q) || Raylib.IsKeyDown(KeyboardKey.A))
            && Direction != Coordinates.right)
        {
            pendingDirection = Coordinates.left;
        }
        else if ((Raylib.IsKeyDown(KeyboardKey.Right) || Raylib.IsKeyDown(KeyboardKey.D))
            && Direction != Coordinates.left)
        {
            pendingDirection = Coordinates.right;
        }
    }

    public void ApplyPendingDirection()
    {
        Direction = pendingDirection;
    }
}

