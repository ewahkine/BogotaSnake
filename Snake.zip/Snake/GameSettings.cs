﻿    public class GameSettings
    {
        public int GridColumns { get; set; } = 24;
        public int GridRows { get; set; } = 14;
        public int CellSize { get; set; } = 32;
        public float SnakeSpeed { get; set; } = 0.1f;
        public int Difficulty { get; set; } = 1;
        public int TargetFPS { get; set; } = 60;
        public float GoldAppleChance { get; set; } = 0.1f;
}
