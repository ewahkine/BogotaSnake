﻿public class RandomProvider
{
    public Random Rng { get; } = new Random();
}
