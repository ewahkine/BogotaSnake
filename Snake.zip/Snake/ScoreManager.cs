﻿using System.Text.Json;
using System.IO;

public class ScoreManager
{
    public int Score { get; set; }
    public int HighScore { get; set; }

    private static readonly string HighScoreFile = "highscore.json";

    public ScoreManager()
    {
        LoadHighScore();
    }

    public void LoadHighScore()
    {
        if (File.Exists(HighScoreFile))
        {
            try
            {
                var json = File.ReadAllText(HighScoreFile);
                var data = JsonSerializer.Deserialize<HighScoreData>(json);
                if (data != null)
                    HighScore = data.HighScore;
            }
            catch
            {
                HighScore = 0;
            }
        }
        else
        {
            HighScore = 0;
        }
    }

    public void SaveHighScore()
    {
        var data = new HighScoreData { HighScore = this.HighScore };
        var json = JsonSerializer.Serialize(data);
        File.WriteAllText(HighScoreFile, json);
    }

    public void TrySetHighScore(int score)
    {
        if (score > HighScore)
        {
            HighScore = score;
            SaveHighScore();
        }
    }

    private class HighScoreData
    {
        public int HighScore { get; set; }
    }
}