﻿using Raylib_cs;

public class AssetManager
{
    private readonly Dictionary<string, Texture2D> textures = new();
    private readonly Dictionary<string, Sound> sounds = new();

    public void LoadTexture(string key, string path)
    {
        textures[key] = Raylib.LoadTexture(path);
    }
    public Texture2D GetTexture(string key) => textures[key];

    public void LoadSound(string key, string path)
    {
        sounds[key] = Raylib.LoadSound(path);
    }
    public Sound GetSound(string key) => sounds[key];

    public void UnloadAll()
    {
        foreach (var tex in textures.Values) Raylib.UnloadTexture(tex);
        foreach (var snd in sounds.Values) Raylib.UnloadSound(snd);
        textures.Clear();
        sounds.Clear();
    }
}
