﻿public enum AppleType
{
    Rouge,
    Or
}

public class Apple
{
    public Coordinates Position { get; set; }
    public AppleType Type { get; set; }

    public Apple(Coordinates position, AppleType type = AppleType.Rouge)
    {
        Position = position;
        Type = type;
    }
}