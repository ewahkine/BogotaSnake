﻿using Raylib_cs;

Raylib.InitWindow(1280, 720, "Snake Bogota");
Raylib.InitAudioDevice();
Console.WriteLine("[MAIN] Fenêtre Raylib initialisée");
////// Service Locator Registration //////

ServiceLocator.Register(new GameSettings());
Console.WriteLine("[MAIN] GameSettings enregistré");

ServiceLocator.Register(new ScoreManager());
Console.WriteLine("[MAIN] ScoreManager enregistré");

ServiceLocator.Register(new RandomProvider());
Console.WriteLine("[MAIN] RandomProvider enregistré");

ServiceLocator.Register(new AssetManager());
Console.WriteLine("[MAIN] AssetManager enregistré");

ServiceLocator.Register(new input());
Console.WriteLine("[MAIN] input enregistré");


ScenesManager.Load<MenuScene>();

while (!Raylib.WindowShouldClose())
{
    ScenesManager.Update(Raylib.GetFrameTime());

    Raylib.BeginDrawing();
    Raylib.ClearBackground(Color.Black);

    ScenesManager.Draw();

    Raylib.EndDrawing();
}
Raylib.CloseAudioDevice();
Raylib.CloseWindow();
