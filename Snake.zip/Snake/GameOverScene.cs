using System.Numerics;
using Raylib_cs;
public class GameOverScene : Scene
{
    private string[] options = { "Rejouer", "Retour au Menu" };
    private int selectedIndex = 0;
    private int highScore;
    private Vector2 screenSize;
    private Texture2D background;
    private Font customFont;

    public GameOverScene(int highScore, Vector2 screenSize)
    {
        this.highScore = highScore;
        this.screenSize = screenSize;
    }

    public override void Load()
    {
        background = Raylib.LoadTexture("gameover.png");
        customFont = Raylib.LoadFont("Tytoon Mist.ttf");
    }

    public override void Update(float deltaTime)
    {
        if (Raylib.IsKeyPressed(KeyboardKey.Up) ||
            Raylib.IsKeyPressed(KeyboardKey.W) ||
            Raylib.IsKeyPressed(KeyboardKey.Z))
        {
            selectedIndex = (selectedIndex - 1 + options.Length) % options.Length;
        }

        if (Raylib.IsKeyPressed(KeyboardKey.Down) ||
            Raylib.IsKeyPressed(KeyboardKey.S))
        {
            selectedIndex = (selectedIndex + 1) % options.Length;
        }

        if (Raylib.IsKeyPressed(KeyboardKey.Enter) ||
            Raylib.IsKeyPressed(KeyboardKey.Space))
            ActivateOption(selectedIndex);
    }

    public override void Draw()
    {
        var destRect = new Rectangle(0, 0, screenSize.X, screenSize.Y);
        var srcRect = new Rectangle(0, 0, background.Width, background.Height);
        Raylib.DrawTexturePro(background, srcRect, destRect, Vector2.Zero, 0, Color.White);

        int highScoreFontSize = 80;
        int optionFontSize = 48;
        int spacing = 40;
        float centerX = screenSize.X / 2;
        float baseY = screenSize.Y / 2 + 100;

        // Highscore en grand et rouge
        string scoreText = $"HighScore: {highScore}";
        Vector2 scoreSize = Raylib.MeasureTextEx(customFont, scoreText, highScoreFontSize, 2);
        Raylib.DrawTextEx(customFont, scoreText, new Vector2(centerX - scoreSize.X / 2, baseY), highScoreFontSize, 2, Color.Red);

        // Options en texte simple, couleur diff�rente si s�lectionn�
        for (int i = 0; i < options.Length; i++)
        {
            string opt = options[i];
            Color color = (i == selectedIndex) ? Color.Yellow : Color.White;
            Vector2 optSize = Raylib.MeasureTextEx(customFont, opt, optionFontSize, 2);
            Raylib.DrawTextEx(
                customFont,
                opt,
                new Vector2(centerX - optSize.X / 2, baseY + highScoreFontSize + spacing + i * (optionFontSize + spacing / 2)),
                optionFontSize,
                2,
                color
            );
        }
    }

    public override void Unload()
    {
        Raylib.UnloadTexture(background);
        Raylib.UnloadFont(customFont);
    }

    private void ActivateOption(int index)
    {
        if (index == 0)
        {
            ScenesManager.Load<GameScene>();
        }
        else if (index == 1)
        {
            ScenesManager.Load<MenuScene>();
        }
    }
}