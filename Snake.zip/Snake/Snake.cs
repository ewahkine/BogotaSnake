﻿using System.Numerics;
using Raylib_cs;
public class Snake
{
    Grid<bool> grid;

    Queue<Coordinates> body = new Queue<Coordinates>();
    Coordinates direction = Coordinates.right;

    public Snake(Coordinates start, Grid<bool> grid, int startSize = 3)
    {
        this.grid = grid;
        direction = Coordinates.right;
        for (int i = startSize - 1; i >= 0; i--)
        {
            var segment = new Coordinates(start.column - direction.column * i, start.row - direction.row * i);
            body.Enqueue(segment);
        }
    }

    public void Move()
    {
        body.Enqueue(body.Last() + direction);
        body.Dequeue();
    }

    public void Draw()
    {
        var settings = ServiceLocator.Get<GameSettings>();
        int cellSize = settings.CellSize;

        Coordinates head = body.Last();
        Coordinates tail = body.First();

        int i = 0;
        int count = body.Count;
        foreach (Coordinates segment in body)
        {
            Vector2 position = grid.GridToWorld(segment);

            if (segment.Equals(tail))
            {
                Raylib.DrawRectangle(
                    (int)position.X,
                    (int)position.Y,
                    cellSize,
                    cellSize,
                    Color.Pink
                );
            }
            else if (segment.Equals(head))
            {
                Raylib.DrawRectangle(
                    (int)position.X,
                    (int)position.Y,
                    cellSize,
                    cellSize,
                    Color.Lime
                );

                int eyeRadius = cellSize / 7;
                int eyeOffsetX = cellSize / 4;
                int eyeOffsetY = cellSize / 4;

                int eye1X = (int)position.X + cellSize - eyeOffsetX;
                int eye1Y = (int)position.Y + eyeOffsetY;
                int eye2X = (int)position.X + cellSize - eyeOffsetX;
                int eye2Y = (int)position.Y + cellSize - eyeOffsetY;

                if (direction == Coordinates.up)
                {
                    eye1X = (int)position.X + eyeOffsetX;
                    eye1Y = (int)position.Y + eyeOffsetY;
                    eye2X = (int)position.X + cellSize - eyeOffsetX;
                    eye2Y = (int)position.Y + eyeOffsetY;
                }
                else if (direction == Coordinates.down)
                {
                    eye1X = (int)position.X + eyeOffsetX;
                    eye1Y = (int)position.Y + cellSize - eyeOffsetY;
                    eye2X = (int)position.X + cellSize - eyeOffsetX;
                    eye2Y = (int)position.Y + cellSize - eyeOffsetY;
                }
                else if (direction == Coordinates.left)
                {
                    eye1X = (int)position.X + eyeOffsetX;
                    eye1Y = (int)position.Y + eyeOffsetY;
                    eye2X = (int)position.X + eyeOffsetX;
                    eye2Y = (int)position.Y + cellSize - eyeOffsetY;
                }

                Raylib.DrawCircle(eye1X, eye1Y, eyeRadius, Color.Black);
                Raylib.DrawCircle(eye2X, eye2Y, eyeRadius, Color.Black);
            }
            else
            {
                Raylib.DrawRectangle(
                    (int)position.X,
                    (int)position.Y,
                    cellSize,
                    cellSize,
                    Color.Green
                );
            }
            i++;
        }
    }

    public void ChangeDirection(Coordinates newDirection)
    {
        if (newDirection == -direction) return;
        direction = newDirection;
    }
    public void SetDirection(Coordinates newDirection)
    {
        direction = newDirection;
    }

    public bool Contains(Coordinates pos)
    {
        return body.Contains(pos);
    }

    public Coordinates NextHead()
    {
        return body.Last() + direction;
    }

    public void Grow()
    {
        body.Enqueue(body.Last() + direction);
    }
}