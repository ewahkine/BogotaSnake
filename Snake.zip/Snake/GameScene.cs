﻿using Raylib_cs;
using System.Numerics;
public class GameScene : Scene
{
    private Grid<bool> grid;
    private Snake snake;
    private input input;
    private float moveTimer = 0f;
    private float moveInterval;
    private Apple apple;
    private int score = 0;
    private Texture2D background;
    private Texture2D appleTexture;
    private Texture2D goldAppleTexture;
    private Vector2 screenSize;
    private Sound appleSound;

    private void SpawnApple()
    {
        var settings = ServiceLocator.Get<GameSettings>();
        var rng = ServiceLocator.Get<RandomProvider>().Rng;
        Coordinates pos;
        do
        {
            pos = new Coordinates(rng.Next(settings.GridColumns), rng.Next(settings.GridRows));
        } while (snake.Contains(pos));
        AppleType type = rng.NextDouble() < settings.GoldAppleChance ? AppleType.Or : AppleType.Rouge;
        apple = new Apple(pos, type);
    }

    public GameScene()
    {
        var settings = ServiceLocator.Get<GameSettings>();
        grid = Grid<bool>.CreateFromSettings(settings, new Vector2(250, 150));
        snake = new Snake(new Coordinates(5, 5), grid);
        input = new input();
        moveInterval = settings.SnakeSpeed;
        SpawnApple();
    }
    public override void Load()
    {
        Console.WriteLine("GameScene Load");
        background = Raylib.LoadTexture("ingame.png");
        screenSize = new Vector2(Raylib.GetScreenWidth(), Raylib.GetScreenHeight());
        appleTexture = Raylib.LoadTexture("pomme.png");
        goldAppleTexture = Raylib.LoadTexture("goldapple.png");
        appleSound = Raylib.LoadSound("apple.mp3");
    }
    public override void Update(float deltaTime)
    {
        moveTimer += deltaTime;
        input.UpdateDirection();
        input.ApplyPendingDirection();
        snake.SetDirection(input.Direction);

        if (moveTimer >= moveInterval)
        {
            var nextHead = snake.NextHead();

            if (nextHead.column < 0 || nextHead.column >= grid.columns ||
                nextHead.row < 0 || nextHead.row >= grid.rows)
            {
                Console.WriteLine("Game Over: Collision avec le mur !");
                ServiceLocator.Get<ScoreManager>().TrySetHighScore(score);
                ScenesManager.Load(new GameOverScene(ServiceLocator.Get<ScoreManager>().HighScore, new Vector2(1280, 720)));
                return;
            }

            if (snake.Contains(nextHead))
            {
                Console.WriteLine("Game Over: Collision avec le corps !");
                ServiceLocator.Get<ScoreManager>().TrySetHighScore(score);
                ScenesManager.Load(new GameOverScene(ServiceLocator.Get<ScoreManager>().HighScore, new Vector2(1280, 720)));
                return;
            }

            if (nextHead == apple.Position)
            {
                Raylib.PlaySound(appleSound);
                snake.Grow();
                if (apple.Type == AppleType.Or)
                    score += 50;
                else
                    score += 10;
                SpawnApple();
            }
            else
            {
                snake.Move();
            }
            moveTimer = 0f;
        }
    }
    public override void Draw()
    {
        var destRect = new Rectangle(0, 0, screenSize.X, screenSize.Y);
        var srcRect = new Rectangle(0, 0, background.Width, background.Height);
        Raylib.DrawTexturePro(background, srcRect, destRect, Vector2.Zero, 0, Color.White);

        grid.Draw();
        snake.Draw();

        var settings = ServiceLocator.Get<GameSettings>();
        Vector2 pos = grid.GridToWorld(apple.Position);
        Texture2D textureToDraw = apple.Type == AppleType.Or ? goldAppleTexture : appleTexture;
        Raylib.DrawTexturePro(
            textureToDraw,
            new Rectangle(0, 0, textureToDraw.Width, textureToDraw.Height),
            new Rectangle(pos.X, pos.Y, settings.CellSize, settings.CellSize),
            Vector2.Zero,
            0,
            Color.White
        );

        Raylib_cs.Raylib.DrawText(
            $"Score : {score}",
            10, 10, 32, Raylib_cs.Color.White
        );

        var scoreManager = ServiceLocator.Get<ScoreManager>();
        Raylib_cs.Raylib.DrawText(
            $"Highscore : {scoreManager.HighScore}",
            10, 50, 32, Raylib_cs.Color.Yellow
        );
    }
    public override void Unload()
    {
        Raylib.UnloadTexture(background);
        Raylib.UnloadTexture(appleTexture);
        Raylib.UnloadTexture(goldAppleTexture);
        Raylib.UnloadSound(appleSound);
    }
}
