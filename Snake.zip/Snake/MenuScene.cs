﻿using Raylib_cs;
using System.Numerics;

public class MenuScene : Scene
{
    private Texture2D background;
    private Vector2 screenSize;
    private Font customFont;
    private string[] menuItems = { "Joueur au jeu", "Controles", "Credits", "Quitter le jeu" };
    private int selectedIndex = 0;
    private bool showControls = false;
    private bool showCredits = false;

    public override void Load()
    {
        background = Raylib.LoadTexture("background.png");
        customFont = Raylib.LoadFont("Tytoon Mist.ttf");
        screenSize = new Vector2(Raylib.GetScreenWidth(), Raylib.GetScreenHeight());
        showControls = false;
        showCredits = false;
    }

    public override void Update(float deltaTime)
    {
        if (showControls || showCredits)
        {
            if (Raylib.IsKeyPressed(KeyboardKey.Escape) || Raylib.IsKeyPressed(KeyboardKey.Enter))
            {
                showControls = false;
                showCredits = false;
            }
            return;
        }

        if (Raylib.IsKeyPressed(KeyboardKey.Down))
        {
            selectedIndex = (selectedIndex + 1) % menuItems.Length;
        }
        if (Raylib.IsKeyPressed(KeyboardKey.Up))
        {
            selectedIndex = (selectedIndex - 1 + menuItems.Length) % menuItems.Length;
        }
        if (Raylib.IsKeyPressed(KeyboardKey.Enter))
        {
            switch (selectedIndex)
            {
                case 0:
                    ScenesManager.Load<GameScene>();
                    break;
                case 1:
                    showControls = true;
                    break;
                case 2:
                    showCredits = true;
                    break;
                case 3:
                    Raylib.CloseWindow();
                    Environment.Exit(0);
                    break;
            }
        }
    }

    public override void Draw()
    {
        var destRect = new Rectangle(0, 0, screenSize.X, screenSize.Y);
        var srcRect = new Rectangle(0, 0, background.Width, background.Height);
        Raylib.DrawTexturePro(background, srcRect, destRect, Vector2.Zero, 0, Color.White);

        int fontSize = 36;
        int spacing = 50;
        float centerX = screenSize.X / 2;
        float offsetY = 200;
        float startY = screenSize.Y / 2 - (menuItems.Length * spacing) / 2 + offsetY;

        if (showControls)
        {
            string controlsTitle = "Controles";
            string controls = "Deplacement : Fleches, ZQSD ou WASD\nEspace : Jouer/Pause\nECHAP ou ENTREE pour revenir";
            int titleWidth = (int)Raylib.MeasureTextEx(customFont, controlsTitle, fontSize, 2).X;
            int controlsWidth = (int)Raylib.MeasureTextEx(customFont, controls, fontSize / 2, 2).X;
            Raylib.DrawTextEx(customFont, controlsTitle, new Vector2(centerX - titleWidth / 2, startY), fontSize, 2, Color.SkyBlue);
            Raylib.DrawTextEx(customFont, controls, new Vector2(centerX - controlsWidth / 2, startY + fontSize + 20), fontSize / 2, 2, Color.White);
            return;
        }

        if (showCredits)
        {
            string creditsTitle = "Credits";
            string credits = "Developpeur: Hernani Direito\nProfesseur: Nicolas Pointet\nECHAP ou ENTREE pour revenir";
            int titleWidth = (int)Raylib.MeasureTextEx(customFont, creditsTitle, fontSize, 2).X;
            int creditsWidth = (int)Raylib.MeasureTextEx(customFont, credits, fontSize / 2, 2).X;
            Raylib.DrawTextEx(customFont, creditsTitle, new Vector2(centerX - titleWidth / 2, startY), fontSize, 2, Color.SkyBlue);
            Raylib.DrawTextEx(customFont, credits, new Vector2(centerX - creditsWidth / 2, startY + fontSize + 20), fontSize / 2, 2, Color.White);
            return;
        }

        for (int i = 0; i < menuItems.Length; i++)
        {
            Color color = (i == selectedIndex) ? Color.Yellow : Color.White;
            int itemWidth = (int)Raylib.MeasureTextEx(customFont, menuItems[i], fontSize, 2).X;
            Raylib.DrawTextEx(
                customFont,
                menuItems[i],
                new Vector2(centerX - itemWidth / 2, startY + i * spacing),
                fontSize,
                2,
                color
            );
        }
    }

    public override void Unload()
    {
        Raylib.UnloadTexture(background);
        Raylib.UnloadFont(customFont);
    }
}
