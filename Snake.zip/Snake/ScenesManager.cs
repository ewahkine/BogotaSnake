﻿public static class ScenesManager
{
    private static Scene? currentScene;

    public static void Load<T>() where T : Scene, new()
    {
        currentScene?.Unload();
        currentScene = new T();
        currentScene.Load();
    }
    public static void Load(Scene scene)
    {
        currentScene?.Unload();
        currentScene = scene;
        currentScene.Load();
    }
    public static void Update(float deltaTime)
    {
        currentScene?.Update(deltaTime);
    }

    public static void Draw()
    {
        currentScene?.Draw();
    }

       
}

